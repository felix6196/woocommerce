# -*- coding: utf-8 -*-
from . import slife_menu
from . import res_config_settings

$(function() {
  var o_sub_menu_size = $('.o_sub_menu').width();
  $('.o_sub_menu_content').width(o_sub_menu_size + 21);
  $('.oe_logo_backend').width(o_sub_menu_size + 21);
});
